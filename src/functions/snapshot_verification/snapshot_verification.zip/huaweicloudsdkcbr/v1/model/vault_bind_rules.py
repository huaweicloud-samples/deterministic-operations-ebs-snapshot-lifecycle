# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VaultBindRules:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'tags': 'list[BindRulesTags]'
    }

    attribute_map = {
        'tags': 'tags'
    }

    def __init__(self, tags=None):
        r"""VaultBindRules

        The model defined in huaweicloud sdk

        :param tags: 按tags过滤自动绑定的资源  最小长度：1  最大长度：5
        :type tags: list[:class:`huaweicloudsdkcbr.v1.BindRulesTags`]
        """
        
        

        self._tags = None
        self.discriminator = None

        if tags is not None:
            self.tags = tags

    @property
    def tags(self):
        r"""Gets the tags of this VaultBindRules.

        按tags过滤自动绑定的资源  最小长度：1  最大长度：5

        :return: The tags of this VaultBindRules.
        :rtype: list[:class:`huaweicloudsdkcbr.v1.BindRulesTags`]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this VaultBindRules.

        按tags过滤自动绑定的资源  最小长度：1  最大长度：5

        :param tags: The tags of this VaultBindRules.
        :type tags: list[:class:`huaweicloudsdkcbr.v1.BindRulesTags`]
        """
        self._tags = tags

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VaultBindRules):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
